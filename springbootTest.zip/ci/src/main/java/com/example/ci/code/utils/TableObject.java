package com.example.ci.code.utils;


import lombok.Data;

@Data
public class TableObject {

    private String aaa;
    private String bbb;

}
