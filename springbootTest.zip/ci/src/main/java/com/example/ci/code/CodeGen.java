package com.example.ci.code;

import cn.hutool.core.bean.BeanUtil;
import cn.hutool.core.util.ArrayUtil;
import cn.hutool.poi.excel.ExcelReader;
import cn.hutool.poi.excel.ExcelUtil;
import cn.hutool.poi.excel.ExcelWriter;
import cn.hutool.poi.excel.WorkbookUtil;

import com.example.ci.code.utils.TableObject;
import com.example.ci.code.utils.WriteObject;
import org.apache.poi.common.usermodel.Hyperlink;

import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.springframework.boot.system.ApplicationHome;

import java.io.File;
import java.io.FileInputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class CodeGen {

    public static void generate(String dataStr,String templateStr){

        ApplicationHome ah = new ApplicationHome(CodeGen.class);
        File file = ah.getSource().getParentFile();
        String absolutePath = file.getAbsolutePath();
//        System.out.println("+++" + file);
        try {
            ExcelReader reader = ExcelUtil.getReader(new FileInputStream(new File(dataStr)));
            Map map = new HashMap();
            map.put("啊啊","aaa");
            map.put( "报表","bbb");
            reader.setHeaderAlias(map);
            List<TableObject> tableObjects = reader.readAll(TableObject.class);
//            System.out.println(tableObjects);

            Workbook wb = WorkbookUtil.createBook(dataStr);
            //获取工作表
            Sheet excelSheet = wb.getSheetAt(0);
            //获取超链接集合
            List<? extends org.apache.poi.ss.usermodel.Hyperlink> hyperlinkList = excelSheet.getHyperlinkList();
            Map<String,Hyperlink> linkMap = new HashMap<>();
            if(ArrayUtil.isNotEmpty(hyperlinkList)) {
                for (Object obj : hyperlinkList) {
                    Hyperlink aa = (Hyperlink) obj;
                    linkMap.put(aa.getLabel(),aa);
//                    System.out.println(aa.getAddress() + aa.getLabel());
                }
            }
            List<WriteObject> writeObjectList = new ArrayList<>();
            if(ArrayUtil.isNotEmpty(writeObjectList)){
                for(TableObject obj : tableObjects){
                    if(linkMap.containsKey(obj.getAaa())){
                        WriteObject writeObject = new WriteObject();
                        BeanUtil.copyProperties(obj,writeObject,true);
                        writeObject.setHyperlink(linkMap.get(obj.getAaa()));
                        writeObjectList.add(writeObject);
                    }
                }
            }

            Workbook book = WorkbookUtil.createBook(templateStr);
            Sheet sheetAt = book.getSheetAt(0);
            int lastRowNum = sheetAt.getLastRowNum();
//            System.out.println(lastRowNum);
            ExcelWriter writer = new ExcelWriter(book, "xxx");

            writer.setSheet(0);
            writer.setCurrentRow(lastRowNum+1);
            writer.write(writeObjectList);
//            Hyperlink hyperlink = writer.createHyperlink(HyperlinkType.URL, "https://hutool.cn","word");

//            writer.write(ListUtil.of(hyperlink));
            //writer.flush(new File("C:\\Users\\ping\\Desktop\\springbootTest\\ci\\src\\main\\java\\com\\example\\ci\\code\\template\\test222.xlsx"));
            writer.flush(new File(absolutePath+File.separator+"generate.xlsx"));
        }catch (Exception e){
            e.printStackTrace();
        }
    }
}
