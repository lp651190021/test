package com.example.ci;

import com.example.ci.code.CodeGen;
import com.example.ci.code.template.CodeGenConfig;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CiApplication {

	public static void main(String[] args) {
		SpringApplication.run(CiApplication.class, args);
		if(args.length>1){
			CodeGen.generate(args[0],args[1]);
		}else {
			CodeGen.generate(CodeGenConfig.dataPath,CodeGenConfig.templatePath);
		}

	}

}
