package com.example.ci.code.utils;

import lombok.Data;
import org.apache.poi.common.usermodel.Hyperlink;

@Data
public class WriteObject {

    private Hyperlink hyperlink;
    private String bbb;
}
