package com.example.ci.code.template;

public class CodeGenConfig {
    public static String dataPath = "C:\\Users\\ping\\Desktop\\springbootTest\\ci\\src\\main\\java\\com\\example\\ci\\code\\template\\data.xlsx";
    public static String templatePath = "C:\\Users\\ping\\Desktop\\springbootTest\\ci\\src\\main\\java\\com\\example\\ci\\code\\template\\template.xlsx";
}
